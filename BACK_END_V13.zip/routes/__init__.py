"""
Route modules initialization.
"""

from . import auth, restaurant, chat, clients, chats

__all__ = ["auth", "restaurant", "chat", "clients", "chats"]

