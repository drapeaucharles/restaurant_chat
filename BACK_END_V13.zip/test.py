from dotenv import load_dotenv
import os
from sqlalchemy import create_engine, text

# Load environment variables
load_dotenv()

DATABASE_URL = os.getenv("DATABASE_URL")

if not DATABASE_URL:
    print("❌ DATABASE_URL is not set in your .env file")
    exit(1)

try:
    engine = create_engine(DATABASE_URL)
    with engine.connect() as connection:
        print("✅ Connected to database.")

        # Count total chat logs
        print("\n📦 Checking chat_logs...")
        chat_logs_result = connection.execute(text("SELECT COUNT(*) FROM chat_logs")).scalar()
        print(f"📝 chat_logs count: {chat_logs_result}")

        # Count total chat messages
        print("\n📦 Checking chat_messages...")
        chat_msgs_result = connection.execute(text("SELECT COUNT(*) FROM chat_messages")).scalar()
        print(f"💬 chat_messages count: {chat_msgs_result}")

        # Preview last 10 messages
        if chat_msgs_result > 0:
            print("\n📬 Last 10 chat_messages (ordered by timestamp DESC):")
            query = text("""
                SELECT id, client_id, sender_type, message, timestamp
                FROM chat_messages
                ORDER BY timestamp DESC
                LIMIT 10
            """)
            rows = connection.execute(query)
            for row in rows:
                print(f"- [{row.timestamp}] ({row.sender_type}) {row.client_id}: {row.message[:80]}")

except Exception as e:
    print("❌ Error accessing DB:", str(e))
